package com.irrigation.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RecentDataActivity extends AppCompatActivity {

    TextView Moisture;
    TextView Temperature;
    //TextView Gas;
    TextView Humidity;
    DatabaseReference mref;
    DatabaseReference tref;
    //DatabaseReference gref;
    DatabaseReference href;
    String mstatus;
    String tstatus;
    //String gstatus;
    String hstatus;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_data);

        Moisture= (TextView) findViewById(R.id.moist);
        mref= FirebaseDatabase.getInstance().getReference();
        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mstatus=dataSnapshot.child("Moisture").getValue().toString();
                Moisture.setText(mstatus);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        });
       Temperature= (TextView) findViewById(R.id.temp);
        tref= FirebaseDatabase.getInstance().getReference();
        tref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                tstatus=dataSnapshot.child("Temperature").getValue().toString();
               Temperature.setText(tstatus);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        });

        Humidity= (TextView) findViewById(R.id.humid);
        href= FirebaseDatabase.getInstance().getReference();
        href.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                hstatus=dataSnapshot.child("Humidity").getValue().toString();
                Humidity.setText(hstatus);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        });


    }


}
